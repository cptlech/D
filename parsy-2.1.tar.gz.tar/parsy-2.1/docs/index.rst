Welcome to parsy's documentation!
=================================

These are the docs for parsy |release|. Check the :doc:`/history` for
significant changes.

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   installation
   overview
   tutorial
   ref/index
   howto/index
   history
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
