============
Installation
============

parsy can be installed with pip::

    pip install parsy


Python 3.7 or greater is required.
