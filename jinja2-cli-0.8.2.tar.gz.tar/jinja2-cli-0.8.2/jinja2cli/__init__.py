"""
jinja2-cli
==========

License: BSD, see LICENSE for more details.
"""

__author__ = "Matt Robenolt"
__version__ = "0.8.2"

from .cli import main  # NOQA
