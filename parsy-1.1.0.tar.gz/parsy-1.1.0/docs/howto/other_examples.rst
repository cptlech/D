==============
Other examples
==============

This section has some further example parsers that you can study. There are also
examples in the :doc:`/tutorial` and in :doc:`/ref/generating`.

JSON parser
===========

.. literalinclude:: ../../examples/json.py
   :language: python
