===============
 API reference
===============

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   primitives
   methods_and_combinators
   generating
   parser_instances
