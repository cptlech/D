from jinjalint.cli import main


main()
