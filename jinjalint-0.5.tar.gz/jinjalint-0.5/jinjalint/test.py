from . import parse_test, util_test, config_test


parse_test.test()
util_test.test()
config_test.test()
